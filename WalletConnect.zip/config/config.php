<?php
$bot_token = ""; /* bot token */
$chat_id = ""; /* chatid */

?>